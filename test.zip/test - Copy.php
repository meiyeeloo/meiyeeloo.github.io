<?php

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $subject = $_POST['subject'];
    $mailFrom = $_POST['email'];
    $message = $_POST['message'];

    $mailTo = "meiyeeloo@hotmail.com";
    $headers = "From my website";
    $txt = $message;

    mail($mailTo, $subject, $txt, $headers);
    header("Location: index.php?sendmail");
}